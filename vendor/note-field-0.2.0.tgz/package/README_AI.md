# note-field — AI Context

Dichte Kontextdatei für KI-Agenten, die `note-field` in ein Projekt einbauen. Enthält Vertrag, Props, Verhalten und Fallstricke. Mensch-Doku: `README.md`.

## Was es ist

`MarkdownNoteField` — wiederverwendbare React-Komponente: Markdown-WYSIWYG-Notizfeld mit Live-Preview (CodeMirror 6 + @retronav/ixora), Catppuccin-Theme. Markdown ist das kanonische Speicherformat (kein HTML-/ProseMirror-Zwischenmodell). Verhält sich wie ein kontrolliertes `<textarea>`: `value` rein, `onChange(markdown)` raus.

## Installation

```bash
npm install note-field
# oder lokal nach npm pack: npm install ./note-field-0.2.0.tgz
```

Voraussetzungen im Ziel-Projekt:
- React `>=18` und react-dom `>=18` (sind `peerDependencies`, NICHT mitgeliefert).
- Bundler, der ESM auflöst (Vite, Next, Webpack 5, …). Paket ist `"type": "module"`, nur ESM-Build.

Nicht nötig: CodeMirror/ixora installieren (sind ins Bundle gebundelt). Kein CSS-Import (Styles injizieren sich selbst zur Laufzeit).

## Minimal-Nutzung

```jsx
import { MarkdownNoteField } from 'note-field'

function Field() {
  const [md, setMd] = useState('')
  return <MarkdownNoteField value={md} onChange={setMd} />
}
```

Das ist vollständig lauffähig. Bild-Einfügen funktioniert ohne weiteres Setup (Default: base64-Fallback).

## Props (vollständig)

| Prop | Typ | Default | Zweck |
|------|-----|---------|-------|
| `value` | `string` | `''` | Markdown-Quelltext (kontrolliert). |
| `onChange` | `(value: string) => void` | — | Feuert bei jeder Änderung mit neuem Markdown. |
| `onUpload` | `(file: File) => Promise<string> \| string` | — | Bild hochladen, gibt finale URL zurück. Fehlt → base64-Data-URI inline. |
| `onUploadError` | `(error: unknown, file: File) => void` | — | Meldet Upload-Fehler vor der Fallback-Behandlung an den Host. |
| `uploadFallback` | `'data-url' \| 'error' \| 'none'` | `'data-url'` | `data-url` = base64 einfügen, `error` = werfen/loggen, `none` = Bild überspringen. |
| `onRemove` | `(url: string) => void` | — | Signal beim Löschen eines Bildes (Host entscheidet über echtes GC). |
| `theme` | `'auto' \| 'light' \| 'dark'` | `'auto'` | `light` = Catppuccin Latte, `dark` = Macchiato, `auto` folgt `prefers-color-scheme`. |
| `id` | `string` | — | Editor-id für Formularintegration. |
| `ariaLabel` | `string` | `'Markdown-Notizfeld'` | Accessible Label für den Editor. |
| `toolbar` | `false \| { layout?: string; mobilePosition?: 'top' \| 'bottom' }` | `true` | Built-in Toolbar deaktivieren oder Host-spezifisch konfigurieren. |
| `toolbarMobilePosition` | `'top' \| 'bottom'` | `'top'` | Toolbar auf Touch/Mobile-Geräten unten anzeigen. |
| `toolbarLayout` | `'wrap' \| string` | `'wrap'` | Anordnung der Format-Toolbar. |
| `tables` | `boolean` | `false` | Markdown-Tabellenwerkzeuge in der Toolbar aktivieren. |
| `readOnly` | `boolean` | `false` | Keine Toolbar, kein Editieren. |
| `placeholder` | `string` | Markdown-Hinweistext | Leertext. |
| `minRows` | `number` | `4` | Mindesthöhe in Zeilen (≈24px/Zeile, min 60px). |
| `maxHeight` | `number \| string \| null` | `null` | Max-Höhe (px/CSS). Gesetzt → internes Scrollen statt Wachsen. |
| `toc` | `boolean` | `false` | Schwebendes Inhaltsverzeichnis einblenden. |
| `className` | `string` | `''` | Zusätzliche Klasse am Root. |

## Exports

```js
import {
  MarkdownNoteField,   // default-Komponente (named re-export)
  commands,            // Namespace: Editier-Commands (s.u.) — selten nötig
  resolveUpload,       // (file, onUpload?) => Promise<url> — interne Upload-Auflösung
  fileToDataURL,       // (file) => Promise<base64-url>
  insertFiles,         // (view, fileList, onUpload?, requestMeta?) => Promise<void>
} from 'note-field'
```

`commands` (jede Funktion nimmt die CodeMirror `EditorView` — nur für eigene Toolbars/Hotkeys; die eingebaute Toolbar braucht das nicht): `toggleBold, toggleItalic, toggleStrike, toggleInlineCode, toggleBulletList, toggleTaskList, toggleQuote, cycleTaskLine, toggleHeading(view, level), toggleOrderedList, toggleCodeBlock, insertHorizontalRule, insertLink(view, url, text?), insertImage(view, url, alt?)`.

Typen liegen in `dist/index.d.ts` (Autocomplete im Consumer).

## Eingebautes Verhalten (ohne Zutun)

- **Toolbar** über dem Feld (außer `readOnly`): Fett/Kursiv/Headings/Listen/Task/Quote/Code/Link/Bild/TOC-Toggle.
- **Hotkeys**: Cmd/Ctrl+B/I, Cmd+L (Task-Zeile zyklen), Alt+Shift+C u.a.
- **Bild einfügen** per Toolbar-Button, Paste (Clipboard-Image), Drag-&-Drop. Vor dem Upload erscheint ein Modal: Feld 1 = Dateiname (geht an `onUpload`), Feld 2 = Alias/Linktext.
- **Bild löschen**: Klick/Tap auf gerendertes Bild → schwebender „Entfernen"-Button → ruft `onRemove(url)`.
- **Live-Preview**: Headings, Listen (mit Nesting + Renumber), Checkboxen, Code-Blöcke (mit Copy-Button, ``` und ~~~), Highlights (`==…==`, `===…===`, `%%…%%`), HR.

## Storage-Modell (wichtig)

Komponente besitzt KEIN Storage. `onUpload`/`onRemove` sind reine Signale:
- `onUpload(file) => url`: Host lädt hoch und liefert die URL für `![alias](url)`. Fehlt der Callback → per Default base64-Inline (self-contained, bläht aber Markdown/Kontext).
- Produktions-Hosts sollten `uploadFallback="error"` oder `"none"` setzen, wenn base64-Inline niemals persistiert werden darf. `onUploadError` ist der Host-Hook für Toasts/Telemetry.
- `onRemove(url)`: Host entscheidet über echtes Löschen (Ref-Count über Notizen / GC mit Schonfrist). Komponente entfernt nur das Markdown.

## Lokale Paketierung / Tests

```bash
npm test
npm run build:lib
npm pack --dry-run
```

Das Paket baut für Tarballs über `prepack`, nicht mehr bei jeder lokalen Installation über `prepare`. Empfohlene lokale Consumer-Form: `npm pack` im Repo und dann im Zielprojekt `npm install ./note-field-0.2.0.tgz`.

## Theming

Palette: Catppuccin Latte (`theme="light"`, auch Default-Styling) / Macchiato (`theme="dark"`). `theme="auto"` schaltet per `prefers-color-scheme`. CSS-Custom-Properties aus `tokens.css` (injiziert); eigene Tokens überschreibbar, indem der Host die `--*`-Vars auf einem Vorfahren neu setzt. Anwendung über `data-theme` am Component-Root.

## Fallstricke für den Consumer-Agenten

- **Nur ein React.** note-field bringt React nicht mit (peer). Bei „Invalid hook call" → `npm ls react` (Dublette beseitigen).
- **Kontrolliert.** Immer `value` + `onChange` paaren; ohne `onChange` ist das Feld effektiv read-only-ish (Tippen verpufft beim nächsten Render).
- **Kein CSS-Import.** Nicht versuchen, eine `.css` zu importieren — gibt es im Paket nicht (injiziert).
- **`maxHeight` setzen** für feste Container, sonst wächst das Feld mit dem Inhalt.
- **`toc` weglassen**, wenn kein Inhaltsverzeichnis gewünscht (Default ist bereits `false`).
- **Bundle ~1 MB** (gzip ~296 KB), CodeMirror-bedingt. Für App-Felder ok.
- **ESM-only.** In reinen CJS-Umgebungen via dynamic `import()` laden.

## Typische Ersetzung (Textarea → note-field)

Vorher:
```jsx
<textarea value={note} onChange={(e) => setNote(e.target.value)} />
```
Nachher:
```jsx
<MarkdownNoteField value={note} onChange={setNote} />
```
`onChange` liefert direkt den String (nicht das Event).
