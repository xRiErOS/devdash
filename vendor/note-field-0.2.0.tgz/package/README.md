# note-field

Reusable markdown-native note editor for React.

`MarkdownNoteField` combines CodeMirror 6 with `@retronav/ixora` live preview and a formatting toolbar. Markdown is the canonical storage format: the component receives a markdown string via `value` and emits markdown via `onChange`.

## Features

- Controlled React component, similar to a `<textarea>`
- Markdown live preview with editable source syntax
- Formatting toolbar for headings, bold, italic, strikethrough, inline code, lists, tasks, quotes, code blocks, links, images and horizontal rules
- Keyboard shortcuts for common formatting actions
- Image insertion from URL, file picker, drag-and-drop and clipboard paste
- Optional image upload and remove callbacks for host-managed storage
- Optional floating table of contents
- Light, dark and auto themes using scoped CSS custom properties
- ESM library build with React as a peer dependency

## Installation

```sh
npm install note-field
```

For local development from this repository:

```sh
npm install
npm run dev
```

## Usage

```jsx
import { useState } from 'react'
import { MarkdownNoteField } from 'note-field'

export function NoteEditor() {
  const [value, setValue] = useState('')

  return (
    <MarkdownNoteField
      value={value}
      onChange={setValue}
    />
  )
}
```

The component is controlled. Pass markdown in through `value`; receive markdown updates through `onChange(markdown)`.

## Props

| Prop | Type | Default | Description |
| --- | --- | --- | --- |
| `value` | `string` | `''` | Markdown source text. |
| `onChange` | `(value: string) => void` | - | Called with the updated markdown string. |
| `onUpload` | `(file: File) => Promise<string> \| string` | - | Upload callback. Must return the final image URL. |
| `onUploadError` | `(error: unknown, file: File) => void` | - | Called when `onUpload` throws before fallback handling. |
| `uploadFallback` | `'data-url' \| 'error' \| 'none'` | `'data-url'` | Controls fallback behavior when upload is missing or fails. |
| `onRemove` | `(url: string) => void` | - | Signal when an image reference is removed from the document. |
| `theme` | `'auto' \| 'light' \| 'dark'` | `'auto'` | Component theme. |
| `id` | `string` | - | Editor id for form integration. |
| `ariaLabel` | `string` | `'Markdown-Notizfeld'` | Accessible editor label. |
| `toolbar` | `false \| { layout?: string; mobilePosition?: 'top' \| 'bottom' }` | `true` | Disable or configure the built-in toolbar. |
| `toolbarMobilePosition` | `'top' \| 'bottom'` | `'top'` | Moves the toolbar to the bottom on touch/mobile devices. |
| `toolbarLayout` | `'wrap' \| 'scroll' \| 'overflow' \| string` | `'wrap'` | Toolbar layout mode. |
| `tables` | `boolean` | `false` | Enables markdown table tools in the toolbar. |
| `readOnly` | `boolean` | `false` | Hides the toolbar and disables editor input. |
| `placeholder` | `string` | Markdown hint | Placeholder text. |
| `minRows` | `number` | `4` | Minimum editor height in approximate text rows. |
| `maxHeight` | `number \| string \| null` | `null` | Maximum editor height. Enables internal scrolling when set. |
| `toc` | `boolean` | `false` | Shows an optional floating table of contents. |
| `className` | `string` | `''` | Additional class for the root element. |

## Media Handling

Images can be inserted from:

- URL dialog
- File picker
- Drag-and-drop
- Clipboard paste

If `onUpload` is provided, the selected file is passed to the host application and the returned URL is inserted as markdown:

```jsx
<MarkdownNoteField
  value={value}
  onChange={setValue}
  onUpload={async (file) => {
    const url = await uploadFile(file)
    return url
  }}
  onRemove={(url) => {
    scheduleFileCleanup(url)
  }}
/>
```

The component does not own storage. `onRemove(url)` is only a signal that a markdown image reference was removed. The host application decides whether and when the underlying file should be deleted.

If no `onUpload` callback is provided, the component falls back to inserting a base64 data URL by default. This is useful for standalone demos, but host applications that persist larger notes should usually provide an upload callback and set `uploadFallback="error"` or `uploadFallback="none"` to avoid persisting accidental base64 blobs.

```jsx
<MarkdownNoteField
  value={value}
  onChange={setValue}
  onUpload={uploadFile}
  onUploadError={(error, file) => reportUploadFailure(error, file)}
  uploadFallback="error"
/>
```

## Markdown Notes

- Task lists follow GitHub-Flavored Markdown syntax: `- [ ] Task` and `- [x] Done`.
- Task markers require whitespace after the closing bracket.
- Custom highlights are supported:
  - `==text==`
  - `===text===`
  - `%%text%%`
- Markdown remains the stored format. There is no HTML or ProseMirror serialization layer.

## Exports

```js
import {
  MarkdownNoteField,
  commands,
  resolveUpload,
  fileToDataURL,
  insertFiles,
} from 'note-field'
```

The `commands` export contains CodeMirror editor commands for custom toolbars or integrations.

## Development

```sh
npm install
npm run dev
npm test
npm run build
npm run build:lib
```

Scripts:

- `npm run dev` starts the Vite demo.
- `npm test` builds the library and runs contract tests.
- `npm run build` builds the demo app.
- `npm run build:lib` builds the reusable library into `dist/`.

## Package Notes

- React and React DOM are peer dependencies.
- The package is ESM-only.
- CodeMirror and ixora are bundled into the library build.
- Component styles are injected by the library build; consumers do not need a separate CSS import.
- Tarballs build through `prepack`. Use `npm pack --dry-run` to inspect published files; for local consumers, prefer `npm pack` plus `npm install ./note-field-0.2.0.tgz` over direct `file:../note-field` installs.
